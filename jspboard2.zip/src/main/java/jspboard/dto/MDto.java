package jspboard.dto;

import java.sql.Timestamp;

public class MDto {

   private int id;
   private String userid;
   private String userpass;
   private String username;
   private String useremail;
   private String usertel;
   private int zipcode;
   private String addr1;
   private String addr2;
   private String userlink;
   private String role;
   private Timestamp wdate;
   
   
   @Override
public String toString() {
	return "MDto [id=" + id + ", userid=" + userid + ", userpass=" + userpass + ", username=" + username
			+ ", useremail=" + useremail + ", usertel=" + usertel + ", zipcode=" + zipcode + ", addr1=" + addr1
			+ ", addr2=" + addr2 + ", userlink=" + userlink + ", role=" + role + ", wdate=" + wdate + "]";
}


/**
 * @return the id
 */
public int getId() {
	return id;
}


/**
 * @param id the id to set
 */
public void setId(int id) {
	this.id = id;
}


/**
 * @return the userid
 */
public String getUserid() {
	return userid;
}


/**
 * @param userid the userid to set
 */
public void setUserid(String userid) {
	this.userid = userid;
}


/**
 * @return the userpass
 */
public String getUserpass() {
	return userpass;
}


/**
 * @param userpass the userpass to set
 */
public void setUserpass(String userpass) {
	this.userpass = userpass;
}


/**
 * @return the username
 */
public String getUsername() {
	return username;
}


/**
 * @param username the username to set
 */
public void setUsername(String username) {
	this.username = username;
}


/**
 * @return the useremail
 */
public String getUseremail() {
	return useremail;
}


/**
 * @param useremail the useremail to set
 */
public void setUseremail(String useremail) {
	this.useremail = useremail;
}


/**
 * @return the usertel
 */
public String getUsertel() {
	return usertel;
}


/**
 * @param usertel the usertel to set
 */
public void setUsertel(String usertel) {
	this.usertel = usertel;
}


/**
 * @return the zipcode
 */
public int getZipcode() {
	return zipcode;
}


/**
 * @param zipcode the zipcode to set
 */
public void setZipcode(int zipcode) {
	this.zipcode = zipcode;
}


/**
 * @return the addr1
 */
public String getAddr1() {
	return addr1;
}


/**
 * @param addr1 the addr1 to set
 */
public void setAddr1(String addr1) {
	this.addr1 = addr1;
}


/**
 * @return the addr2
 */
public String getAddr2() {
	return addr2;
}


/**
 * @param addr2 the addr2 to set
 */
public void setAddr2(String addr2) {
	this.addr2 = addr2;
}


/**
 * @return the userlink
 */
public String getUserlink() {
	return userlink;
}


/**
 * @param userlink the userlink to set
 */
public void setUserlink(String userlink) {
	this.userlink = userlink;
}


/**
 * @return the role
 */
public String getRole() {
	return role;
}


/**
 * @param role the role to set
 */
public void setRole(String role) {
	this.role = role;
}


/**
 * @return the wdate
 */
public Timestamp getWdate() {
	return wdate;
}


/**
 * @param wdate the wdate to set
 */
public void setWdate(Timestamp wdate) {
	this.wdate = wdate;
}
}

